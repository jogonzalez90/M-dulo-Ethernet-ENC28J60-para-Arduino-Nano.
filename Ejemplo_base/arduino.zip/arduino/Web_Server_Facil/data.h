
const char* ssid_1     = "xxxx";
const char* password_1 = "xxxx";
const char* ssid_2     = "Subcribanse";
const char* password_2 = "alswnet";

const String Pagina =  R"====(HTTP/1.1 200 OK
Content-Type: text/html

<!DOCTYPE HTML>
<html>
)====";
